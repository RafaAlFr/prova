const db = require("./banco")

const Muitotop = db.sequelize.define('muitotop',{
    nome:{
        type: db.Sequelize.STRING
    },
    endereco:{
        type: db.Sequelize.STRING
    },
    bairro:{
        type: db.Sequelize.STRING
    },
    cep:{
        type: db.Sequelize.INTEGER
    },
    cidade:{
        type: db.Sequelize.TEXT
    },
    estado:{
        type: db.Sequelize.TEXT
    }
})

Muitotop.sync({force:true})

module.exports = Muitotop