const express = require("express")
const app = express()
const handlebars = require("express-handlebars").engine
const hand = require("handlebars")
const bodyParser = require("body-parser")
const post = require("./models/post")

hand.registerHelper("eq", function(a,b){
    return a === b;
})

app.engine("handlebars", handlebars({defaultLayout: "main"}))
app.set("view engine", "handlebars")

app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())


app.get("/", function(req, res){
    res.render("primeira_pagina")
})

app.get("/consulta", function(req, res){
    post.findAll().then(function(post){
        res.render("consulta", {post})
    })
})

app.get("/editar/:id", function(req, res){
    post.findAll({where: {'id': req.params.id}}).then(function(post){
       
        res.render("editar", { post });
    })
})

app.post("/cadastrar", function(req, res){
    post.create({
        nome: req.body.nome,
        endereco: req.body.telefone,
        bairro: req.body.origem,
        cep: req.body.data_contato,
        cidade: req.body.observacao,
        estado: req.body.estado
    }).then(function(){
        res.redirect("/")
    })
})

app.post("/atualizar", function(req, res){
    post.update({
        nome: req.body.nome,
        endereco: req.body.telefone,
        bairro: req.body.origem,
        cep: req.body.data_contato,
        cidade: req.body.observacao,
        estado: req.body.estado
    },{
        where: {
            id: req.body.id
        }
    }).then(function(){
        res.redirect("/consulta")
    })
})

app.listen(3081, function(){
    console.log("Servidor ativo!")
})